namespace OutboundIntegrationService.Events
{
    public class SmsRequestSent
    {
        public Guid CommandId { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
