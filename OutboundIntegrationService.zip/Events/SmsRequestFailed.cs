namespace OutboundIntegrationService.Events
{
    public class SmsRequestFailed
    {
        public Guid CommandId { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
