namespace OutboundIntegrationService.Events
{
    public class SmsRequestRejected
    {
        public Guid CommandId { get; set; }
        public string Reason { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
