using OutboundIntegrationService.Commands;
using OutboundIntegrationService.Abstractions;
using OutboundIntegrationService.Events;

namespace OutboundIntegrationService.Subscribers
{
    public class CommandSubscriber
    {
        private readonly IKeyValueStore _store;
        private readonly IExternalSmsApi _smsApi;
        private readonly IPublisher _publisher;

        public CommandSubscriber(IKeyValueStore store, IExternalSmsApi smsApi, IPublisher publisher)
        {
            _store = store;
            _smsApi = smsApi;
            _publisher = publisher;
        }

        public void Handle(SendSmsCommand command)
        {
            if (command == null || string.IsNullOrWhiteSpace(command.PhoneNumber) || string.IsNullOrWhiteSpace(command.Message))
            {
                _publisher.Publish(new SmsRequestRejected
                {
                    CommandId = command?.CommandId ?? Guid.Empty,
                    Reason = "Invalid command",
                    Timestamp = DateTime.UtcNow
                });
                return;
            }

            if (_store.Exists(command.CommandId))
            {
                // Already processed, skip
                return;
            }

            try
            {
                var success = _smsApi.SendSms(command.PhoneNumber, command.Message);
                _store.Store(command.CommandId);

                if (success)
                {
                    _publisher.Publish(new SmsRequestSent
                    {
                        CommandId = command.CommandId,
                        PhoneNumber = command.PhoneNumber,
                        Timestamp = DateTime.UtcNow
                    });
                }
                else
                {
                    _publisher.Publish(new SmsRequestFailed
                    {
                        CommandId = command.CommandId,
                        ErrorMessage = "External API failed",
                        Timestamp = DateTime.UtcNow
                    });
                }
            }
            catch (Exception ex)
            {
                _publisher.Publish(new SmsRequestFailed
                {
                    CommandId = command.CommandId,
                    ErrorMessage = ex.Message,
                    Timestamp = DateTime.UtcNow
                });
            }
        }
    }
}
