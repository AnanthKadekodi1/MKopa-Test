namespace OutboundIntegrationService.Commands
{
    public class SendSmsCommand
    {
        public Guid CommandId { get; set; }
        public string PhoneNumber { get; set; }
        public string Message { get; set; }
        public string ServiceId { get; set; }
        public string BillingReference { get; set; }
    }
}
