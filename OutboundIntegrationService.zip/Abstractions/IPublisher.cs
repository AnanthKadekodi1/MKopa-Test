namespace OutboundIntegrationService.Abstractions
{
    public interface IPublisher
    {
        void Publish<T>(T @event);
    }
}
