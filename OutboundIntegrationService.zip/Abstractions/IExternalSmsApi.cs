namespace OutboundIntegrationService.Abstractions
{
    public interface IExternalSmsApi
    {
        bool SendSms(string phoneNumber, string message);
    }
}
