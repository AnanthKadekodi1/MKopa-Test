namespace OutboundIntegrationService.Abstractions
{
    public interface IKeyValueStore
    {
        bool Exists(Guid key);
        void Store(Guid key);
    }
}
