using NUnit.Framework;
using Moq;
using OutboundIntegrationService.Commands;
using OutboundIntegrationService.Abstractions;
using OutboundIntegrationService.Subscribers;
using OutboundIntegrationService.Events;
using System;

namespace OutboundIntegrationService.Tests
{
    public class CommandSubscriberTests
    {
        private Mock<IKeyValueStore> _storeMock;
        private Mock<IExternalSmsApi> _smsApiMock;
        private Mock<IPublisher> _publisherMock;
        private CommandSubscriber _subscriber;

        [SetUp]
        public void Setup()
        {
            _storeMock = new Mock<IKeyValueStore>();
            _smsApiMock = new Mock<IExternalSmsApi>();
            _publisherMock = new Mock<IPublisher>();
            _subscriber = new CommandSubscriber(_storeMock.Object, _smsApiMock.Object, _publisherMock.Object);
        }

        [Test]
        public void Handle_InvalidCommand_PublishesRejectedEvent()
        {
            var invalidCommand = new SendSmsCommand { CommandId = Guid.NewGuid(), PhoneNumber = "", Message = "" };

            _subscriber.Handle(invalidCommand);

            _publisherMock.Verify(p => p.Publish(It.IsAny<SmsRequestRejected>()), Times.Once);
        }

        [Test]
        public void Handle_DuplicateCommand_DoesNotPublishAgain()
        {
            var commandId = Guid.NewGuid();
            var command = new SendSmsCommand { CommandId = commandId, PhoneNumber = "12345", Message = "Hello" };
            _storeMock.Setup(s => s.Exists(commandId)).Returns(true);

            _subscriber.Handle(command);

            _publisherMock.Verify(p => p.Publish(It.IsAny<object>()), Times.Never);
        }

        [Test]
        public void Handle_SuccessfulSend_PublishesSentEvent()
        {
            var command = new SendSmsCommand { CommandId = Guid.NewGuid(), PhoneNumber = "12345", Message = "Hello" };
            _storeMock.Setup(s => s.Exists(command.CommandId)).Returns(false);
            _smsApiMock.Setup(api => api.SendSms(command.PhoneNumber, command.Message)).Returns(true);

            _subscriber.Handle(command);

            _publisherMock.Verify(p => p.Publish(It.IsAny<SmsRequestSent>()), Times.Once);
        }

        [Test]
        public void Handle_ApiFailure_PublishesFailedEvent()
        {
            var command = new SendSmsCommand { CommandId = Guid.NewGuid(), PhoneNumber = "12345", Message = "Hello" };
            _storeMock.Setup(s => s.Exists(command.CommandId)).Returns(false);
            _smsApiMock.Setup(api => api.SendSms(command.PhoneNumber, command.Message)).Returns(false);

            _subscriber.Handle(command);

            _publisherMock.Verify(p => p.Publish(It.IsAny<SmsRequestFailed>()), Times.Once);
        }

        [Test]
        public void Handle_ApiThrowsException_PublishesFailedEvent()
        {
            var command = new SendSmsCommand { CommandId = Guid.NewGuid(), PhoneNumber = "12345", Message = "Hello" };
            _storeMock.Setup(s => s.Exists(command.CommandId)).Returns(false);
            _smsApiMock.Setup(api => api.SendSms(command.PhoneNumber, command.Message)).Throws(new Exception("API Down"));

            _subscriber.Handle(command);

            _publisherMock.Verify(p => p.Publish(It.IsAny<SmsRequestFailed>()), Times.Once);
        }
    }
}
