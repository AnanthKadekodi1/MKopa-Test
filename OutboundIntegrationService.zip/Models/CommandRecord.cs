namespace OutboundIntegrationService.Models
{
    public class CommandRecord
    {
        public Guid CommandId { get; set; }
        public DateTime ProcessedAt { get; set; }
    }
}
