using Microsoft.Extensions.Logging;
using Moq;
using SmsOutboundService.Interface;
using SmsOutboundService.Models;
using SmsOutboundService.Models.Commands;
using SmsOutboundService.Models.Events;
using SmsOutboundService.Services;
using Xunit;

namespace SmsOutboundService.Tests;

public class SmsCommandSubscriberTests
{
    private readonly Mock<IExternalSmsService> _mockExternalSmsService;
    private readonly Mock<IKeyValueStore> _mockKeyValueStore;
    private readonly Mock<IEventPublisher> _mockEventPublisher;
    private readonly Mock<ILogger<SmsCommandSubscriber>> _mockLogger;
    private readonly SmsCommandSubscriber _subscriber;

    public SmsCommandSubscriberTests()
    {
        _mockExternalSmsService = new Mock<IExternalSmsService>();
        _mockKeyValueStore = new Mock<IKeyValueStore>();
        _mockEventPublisher = new Mock<IEventPublisher>();
        _mockLogger = new Mock<ILogger<SmsCommandSubscriber>>();

        _subscriber = new SmsCommandSubscriber(
            _mockExternalSmsService.Object,
            _mockKeyValueStore.Object,
            _mockEventPublisher.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithValidCommand_ShouldCallExternalServiceAndPublishSuccessEvent()
    {
        // Arrange
        var command = CreateValidCommand();
        var externalReferenceId = "SMS_12345";

        _mockKeyValueStore
            .Setup(x => x.GetKeyAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((string?)null);

        _mockExternalSmsService
            .Setup(x => x.SendSmsAsync(command.PhoneNumber, command.Content,  It.IsAny<CancellationToken>()))
            .ReturnsAsync(SmsSubmissionResult.Success(externalReferenceId));

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockExternalSmsService.Verify(
            x => x.SendSmsAsync(command.PhoneNumber, command.Content, It.IsAny<CancellationToken>()),
            Times.Once);

        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmittedEvent>(e => 
                e.CommandId == command.CommandId &&
                e.PhoneNumber == command.PhoneNumber &&
                e.ExternalReferenceId == externalReferenceId &&
                e.Content == command.Content), It.IsAny<CancellationToken>()),
            Times.Once);

        _mockKeyValueStore.Verify(
            x => x.SetKeyAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithExternalServiceFailure_ShouldPublishFailureEvent()
    {
        // Arrange
        var command = CreateValidCommand();
        var errorCode = "PROVIDER_ERROR";
        var errorMessage = "SMS provider is temporarily unavailable";

        _mockKeyValueStore
            .Setup(x => x.GetKeyAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((string?)null);

        _mockExternalSmsService
            .Setup(x => x.SendSmsAsync(command.PhoneNumber, command.Content, It.IsAny<CancellationToken>()))
            .ReturnsAsync(SmsSubmissionResult.Failure(errorCode, errorMessage, isRetryable: true));

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmissionFailedEvent>(e => 
                e.CommandId == command.CommandId &&
                e.PhoneNumber == command.PhoneNumber &&
                e.ErrorCode == errorCode &&
                e.ErrorMessage == errorMessage), It.IsAny<CancellationToken>()),
            Times.Once);

        _mockKeyValueStore.Verify(
            x => x.SetKeyAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithDuplicateCommand_ShouldPublishDuplicateEvent()
    {
        // Arrange
        var command = CreateValidCommand();
        var existingEventId = "existingevent123";
        var cachedResult = $$"""{"EventId":"{{existingEventId}}","EventType":"SmsSubmittedEvent","StoredAt":"2024-01-01T10:00:00Z"}""";

        _mockKeyValueStore
            .Setup(x => x.GetKeyAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(cachedResult);

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockExternalSmsService.Verify(
            x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(),  It.IsAny<CancellationToken>()),
            Times.Never);

        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsDuplicateEvent>(e => 
                e.CommandId == command.CommandId &&
                e.PhoneNumber == command.PhoneNumber &&
                e.OriginalEventId == existingEventId &&
                e.OriginalEventType == "SmsSubmittedEvent"), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Theory]
    [InlineData("")]
    [InlineData("invalid")]
    [InlineData("1234567890")]
    public async Task ProcessSendSmsCommandAsync_WithInvalidPhoneNumber_ShouldPublishValidationFailureEvent(
        string phoneNumber)
    {
        // Arrange
        var command = new SendSmsCommand
        {
            CommandId = Guid.NewGuid().ToString(),
            PhoneNumber = phoneNumber,
            Content = "Test message"
        };

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockExternalSmsService.Verify(
            x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()),
            Times.Never);

        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmissionFailedEvent>(e => 
                e.CommandId == command.CommandId &&
                e.ErrorCode == "VALIDATION_ERROR"), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData(null)]
    public async Task ProcessSendSmsCommandAsync_WithInvalidContent_ShouldPublishValidationFailureEvent(string? content)
    {
        // Arrange
        var command = new SendSmsCommand
        {
            CommandId = Guid.NewGuid().ToString(),
            PhoneNumber = "+12334567",
            Content = content!
        };

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmissionFailedEvent>(e => 
                e.ErrorCode == "VALIDATION_ERROR"), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithContentTooLong_ShouldPublishValidationFailureEvent()
    {
        // Arrange
        var command = new SendSmsCommand
        {
            CommandId = Guid.NewGuid().ToString(),
            PhoneNumber = "+12334567",
            Content = new string('A', 161) 
        };

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmissionFailedEvent>(e => 
                e.ErrorCode == "VALIDATION_ERROR"), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithExternalServiceException_ShouldPublishFailureEvent()
    {
        // Arrange
        var command = CreateValidCommand();

        _mockKeyValueStore
            .Setup(x => x.GetKeyAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((string?)null);

        _mockExternalSmsService
            .Setup(x => x.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new HttpRequestException("Network error"));

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmissionFailedEvent>(e => 
                e.CommandId == command.CommandId &&
                e.ErrorCode == "EXTERNAL_SMS_SERVICE_ERROR"), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithNullCommand_ShouldThrowArgumentNullException()
    {
        // Act & Assert
        await Assert.ThrowsAsync<ArgumentNullException>(() => 
            _subscriber.ProcessSendSmsCommandAsync(null!));
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithValidCommand_ShouldStoreIdempotencyRecord()
    {
        // Arrange
        var command = CreateValidCommand();
        var externalReferenceId = "SMS_12345";

        _mockKeyValueStore
            .Setup(x => x.GetKeyAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((string?)null);

        _mockExternalSmsService
            .Setup(x => x.SendSmsAsync(command.PhoneNumber, command.Content, It.IsAny<CancellationToken>()))
            .ReturnsAsync(SmsSubmissionResult.Success(externalReferenceId));

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockKeyValueStore.Verify(
            x => x.SetKeyAsync(
                $"CommandId:{command.CommandId}",
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task ProcessSendSmsCommandAsync_WithCorrelationId_ShouldIncludeInEvents()
    {
        // Arrange
        var correlationId = "correlation-123";
        var command = CreateValidCommand() with { CorrelationId = correlationId };
        var externalReferenceId = "SMS_12345";

        _mockKeyValueStore
            .Setup(x => x.GetKeyAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((string?)null);

        _mockExternalSmsService
            .Setup(x => x.SendSmsAsync(command.PhoneNumber, command.Content, It.IsAny<CancellationToken>()))
            .ReturnsAsync(SmsSubmissionResult.Success(externalReferenceId));

        // Act
        await _subscriber.ProcessSendSmsCommandAsync(command);

        // Assert
        _mockEventPublisher.Verify(
            x => x.PublishAsync(It.Is<SmsSubmittedEvent>(e => 
                e.CorrelationId == correlationId), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    private static SendSmsCommand CreateValidCommand()
    {
        return new SendSmsCommand
        {
            CommandId = Guid.NewGuid().ToString(),
            PhoneNumber = "+254712345678",
            Content = "Test SMS message",
            CorrelationId = "test-correlation-123"
        };
    }
}
