# A .NET 8 Implementation of SMS Command Subscriber that has validation, event publishing and idempotency

## The take-home task implements Command Subscriber Service. 

### Key Capabilities

- **Command Processing**: Validates and processes `SendSmsCommand` requests
- **Idempotency Controls**: Prevents duplicate SMS sending n
- **Event Publishing**: Publishes events for all processing outcomes (success, failure, duplicates)
- **Validation**: Includes phone number format and content length
- **Error Handling**: Error handling implemented
- **Infrastructure Abstraction**: Zero dependencies on specific infrastructure implementations

## Features
- Command Processing
- Idempotency Controls
- Event Publishing
- Error Handling

## How to Use
### Prerequisites
- **.NET 8.0 SDK** or later
- **Visual Studio 2022** 

### Installation

1. **Clone the repository**
   ```
   git clone <repository-url>
   cd SmsOutboundService
   ```

2. **Restore dependencies**
   ```dotnet restore```

3. **Build the solution**
   ```dotnet build```

4. **Run tests**
   ```dotnet test```

### Test Coverage
- Happy Path Scenarios
- Validation Failures
- Idempotency Controls
- External Service Integration
- Edge Cases & Error Handling

### Running Tests
 - Can run tests via test explorer in visual studio

## Implementation Highlights

1. Complete Infrastructure Abstraction
2. Enterprise-Grade Idempotency
3. Comprehensive Validation
4. Event-Driven Architecture
5. Production-Ready Design
6. Thorough Testing
7. Clean Architecture

## Limitations & Considerations

#### 1. **Retry Logic & Resilience**
- **No automatic retry** for transient failures with SMS providers
- **No dead letter queue** handling for persistent failures

#### 2. **Phone Number Validation**
- Very basic validation

#### 3. **Idempotency Race Conditions**
- Race conditions can happen idempotency conditions

#### 4. **Content & Encoding Limitations**
- Only fixed 160 character limitation

#### 5. **Processing Limitations**
- Only implemented synchronous processing

#### 6. **Error Information Leakage**
- Messages exposed during error logging

#### 7. **Test Coverage Gaps**
- No integration tests with real infrastructure
- No end-to-end testing with actual SMS providers

## How I used AI in this project

1. Check the properties of an SMS
2. Debugging failed unit tests
3. Getting refactoring suggestions about certain aspects of code such as SmsCommanderSubscriber class
4. Reference examples and Idempotency
5. Get some feedback on my implemented classes, methods, solution
6. Generate some methods in my class - such as when I implement an interface, I can allow the AI to generated the interface class

