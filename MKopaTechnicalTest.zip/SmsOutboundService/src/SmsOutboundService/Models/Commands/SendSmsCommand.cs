using System.ComponentModel.DataAnnotations;

namespace SmsOutboundService.Models.Commands;

public record SendSmsCommand
{

    public required string CommandId { get; init; }

    public required string PhoneNumber { get; init; }

    [Required]
    [StringLength(160, MinimumLength = 1, ErrorMessage = "SMS content must be between 1 and 160 characters")]
    public required string Content { get; init; }
    public string? CorrelationId { get; init; }

}

