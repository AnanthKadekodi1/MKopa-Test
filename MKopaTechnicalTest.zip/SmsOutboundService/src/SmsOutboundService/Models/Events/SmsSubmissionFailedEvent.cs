﻿namespace SmsOutboundService.Models.Events
{
    public class SmsSubmissionFailedEvent : SmsEventBase
    {
        public required string ErrorCode { get; init; }
        public required string ErrorMessage { get; init; }
        public required string Content { get; init; }
    }
}
