namespace SmsOutboundService.Models.Events;

public abstract class SmsEventBase
{
    public required string EventId { get; init; }
    public required string CommandId { get; init; }
    public required string PhoneNumber { get; init; }
    public string? CorrelationId { get; init; }
}
