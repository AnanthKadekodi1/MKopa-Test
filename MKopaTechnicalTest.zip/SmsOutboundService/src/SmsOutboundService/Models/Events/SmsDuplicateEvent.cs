﻿namespace SmsOutboundService.Models.Events
{
    public class SmsDuplicateEvent : SmsEventBase
    {
        public required string OriginalEventId { get; init; }
        public required string OriginalEventType { get; init; }
    }
}
