﻿namespace SmsOutboundService.Models.Events
{
    public class SmsSubmittedEvent : SmsEventBase
    {
        public required string ExternalReferenceId { get; init; }
        public required string Content { get; init; }
        public string? SenderId { get; init; }
    }
}
