﻿namespace SmsOutboundService.Models
{
    public class SmsSubmissionResult
    {
        public required bool IsSuccess { get; init; }

        public string? ExternalReferenceId { get; init; }

        public string? ErrorCode { get; init; }

        public string? ErrorMessage { get; init; }

        public bool IsRetryable { get; init; }

        public static SmsSubmissionResult Success(string externalReferenceId) => new()
        {
            IsSuccess = true,
            ExternalReferenceId = externalReferenceId
        };

        public static SmsSubmissionResult Failure(string errorCode, string errorMessage, bool isRetryable = false) => new()
        {
            IsSuccess = false,
            ErrorCode = errorCode,
            ErrorMessage = errorMessage,
            IsRetryable = isRetryable
        };
    }
}
