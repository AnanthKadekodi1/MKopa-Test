using SmsOutboundService.Models.Commands;

namespace SmsOutboundService.Interface;

public interface ICommandSubscriber
{
    Task ProcessSendSmsCommandAsync(SendSmsCommand command, CancellationToken cancellationToken = default);
}


