using SmsOutboundService.Models;

namespace SmsOutboundService.Interface;

public interface IExternalSmsService
{
    Task<SmsSubmissionResult> SendSmsAsync(
        string phoneNumber, 
        string content, 
        CancellationToken cancellationToken = default);
}

