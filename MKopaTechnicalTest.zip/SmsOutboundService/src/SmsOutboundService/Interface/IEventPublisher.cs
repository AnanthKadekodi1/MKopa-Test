using SmsOutboundService.Models.Events;

namespace SmsOutboundService.Interface;

public interface IEventPublisher
{
    Task PublishAsync<TEvent>(TEvent eventData, CancellationToken cancellationToken = default) where TEvent : SmsEventBase;
}
