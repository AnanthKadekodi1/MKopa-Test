namespace SmsOutboundService.Interface;

public interface IKeyValueStore
{
    Task SetKeyAsync(string key, string value, CancellationToken cancellationToken = default);

    Task<string?> GetKeyAsync(string key, CancellationToken cancellationToken = default);
}
