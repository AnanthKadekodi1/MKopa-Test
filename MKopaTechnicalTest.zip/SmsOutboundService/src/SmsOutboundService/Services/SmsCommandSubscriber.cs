using Microsoft.Extensions.Logging;
using SmsOutboundService.Interface;
using SmsOutboundService.Models.Commands;
using SmsOutboundService.Models.Events;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace SmsOutboundService.Services;

public class SmsCommandSubscriber : ICommandSubscriber
{
    private readonly IExternalSmsService _externalSmsService;
    private readonly IKeyValueStore _keyValueStore;
    private readonly IEventPublisher _eventPublisher;
    private readonly ILogger<SmsCommandSubscriber> _logger;

    private const string IdempotencyKeyPrefix = "CommandId:";

    public SmsCommandSubscriber(
        IExternalSmsService externalSmsService,
        IKeyValueStore keyValueStore,
        IEventPublisher eventPublisher,
        ILogger<SmsCommandSubscriber> logger)
    {
        _externalSmsService = externalSmsService;
        _keyValueStore = keyValueStore;
        _eventPublisher = eventPublisher;
        _logger = logger;
    }

    public async Task ProcessSendSmsCommandAsync(SendSmsCommand command, CancellationToken cancellationToken = default)
    {
        if (command == null)
        {
            throw new ArgumentNullException(nameof(command));
        }

        _logger.LogInformation("Processing SendSMS command {CommandId} for phone number {PhoneNumber}", 
            command.CommandId, command.PhoneNumber);

        try
        {
            ValidateCommand(command);

            var idempotencyKey = GetIdempotencyKey(command.CommandId);
            var existingResult = await _keyValueStore.GetKeyAsync(idempotencyKey, cancellationToken);

            if (!string.IsNullOrEmpty(existingResult))
            {
                await HandleDuplicateCommand(command, existingResult, cancellationToken);
                return;
            }

            await ProcessNewSmsCommand(command, idempotencyKey, cancellationToken);
        }
        catch (ValidationException ex)
        {
            _logger.LogWarning("Validation failed for SendSMS command {CommandId}: {ValidationError}", 
                command.CommandId, ex.Message);
            
            await PublishValidationFailedEvent(command, ex.Message, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing SendSMS command {CommandId}", command.CommandId);
            
            await PublishUnexpectedErrorEvent(command, ex.Message, cancellationToken);
        }
    }

    private static void ValidateCommand(SendSmsCommand command)
    {
        var validationContext = new ValidationContext(command);
        var validationResults = new List<ValidationResult>();

        if (!Validator.TryValidateObject(command, validationContext, validationResults, true))
        {
            var errors = string.Join("; ", validationResults.Select(r => r.ErrorMessage));
            throw new ValidationException($"Command validation failed: {errors}");
        }

        if (string.IsNullOrWhiteSpace(command.CommandId))
        {
            throw new ValidationException("CommandId cannot be empty");
        }

        if (string.IsNullOrWhiteSpace(command.Content))
        {
            throw new ValidationException("SMS content cannot be empty");
        }

        if (!IsValidPhoneNumber(command.PhoneNumber))
        {
            throw new ValidationException("Phone number must start with +");
        }
    }

    private static bool IsValidPhoneNumber(string phoneNumber)
    {
        return !string.IsNullOrWhiteSpace(phoneNumber) && 
               phoneNumber.StartsWith('+') && 
               phoneNumber.Length >= 8 && 
               phoneNumber.Length <= 16 && 
               phoneNumber.Skip(1).All(char.IsDigit);
    }

    private async Task ProcessNewSmsCommand(SendSmsCommand command, string idempotencyKey, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Processing new SMS command {CommandId}", command.CommandId);

        try
        {
            var result = await _externalSmsService.SendSmsAsync(
                command.PhoneNumber, 
                command.Content,
                cancellationToken);

            if (result.IsSuccess)
            {
                var successEvent = new SmsSubmittedEvent
                {
                    EventId = Guid.NewGuid().ToString(),
                    CommandId = command.CommandId,
                    PhoneNumber = command.PhoneNumber,
                    ExternalReferenceId = result.ExternalReferenceId!,
                    Content = command.Content,
                    CorrelationId = command.CorrelationId
                };

                await Task.WhenAll(
                    StoreIdempotencyRecord(idempotencyKey, successEvent, cancellationToken),
                    _eventPublisher.PublishAsync(successEvent, cancellationToken)
                );

                _logger.LogInformation("SMS command {CommandId} processed successfully with external reference {ExternalReferenceId}", 
                    command.CommandId, result.ExternalReferenceId);
            }
            else
            {
                var failureEvent = new SmsSubmissionFailedEvent
                {
                    EventId = Guid.NewGuid().ToString(),
                    CommandId = command.CommandId,
                    PhoneNumber = command.PhoneNumber,
                    ErrorCode = result.ErrorCode!,
                    ErrorMessage = result.ErrorMessage!,
                    Content = command.Content,
                    CorrelationId = command.CorrelationId
                };

                await Task.WhenAll(
                    StoreIdempotencyRecord(idempotencyKey, failureEvent, cancellationToken),
                    _eventPublisher.PublishAsync(failureEvent, cancellationToken)
                );

                _logger.LogWarning("SMS command {CommandId} failed: {ErrorCode} - {ErrorMessage}", 
                    command.CommandId, result.ErrorCode, result.ErrorMessage);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error calling external SMS service for command {CommandId}", command.CommandId);
            
            var failureEvent = new SmsSubmissionFailedEvent
            {
                EventId = Guid.NewGuid().ToString(),
                CommandId = command.CommandId,
                PhoneNumber = command.PhoneNumber,
                ErrorCode = "EXTERNAL_SMS_SERVICE_ERROR",
                ErrorMessage = ex.Message,
                Content = command.Content,
                CorrelationId = command.CorrelationId
            };

            await Task.WhenAll(
                StoreIdempotencyRecord(idempotencyKey, failureEvent, cancellationToken),
                _eventPublisher.PublishAsync(failureEvent, cancellationToken)
            );
        }
    }

    private async Task HandleDuplicateCommand(SendSmsCommand command, string existingResult, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Duplicate sms detected for {CommandId}, returning cached result", command.CommandId);

        try
        {
            var cachedEvent = JsonSerializer.Deserialize<CachedEventResult>(existingResult);
            if (cachedEvent != null)
            {
                var duplicateEvent = new SmsDuplicateEvent
                {
                    EventId = Guid.NewGuid().ToString(),
                    CommandId = command.CommandId,
                    PhoneNumber = command.PhoneNumber,
                    OriginalEventId = cachedEvent.EventId,
                    OriginalEventType = cachedEvent.EventType,
                    CorrelationId = command.CorrelationId
                };

                await _eventPublisher.PublishAsync(duplicateEvent, cancellationToken);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling duplicate command {CommandId}", command.CommandId);
        }
    }

    private async Task PublishValidationFailedEvent(SendSmsCommand command, string validationError, CancellationToken cancellationToken)
    {
        var failureEvent = new SmsSubmissionFailedEvent
        {
            EventId = Guid.NewGuid().ToString(),
            CommandId = command.CommandId,
            PhoneNumber = command.PhoneNumber,
            ErrorCode = "VALIDATION_ERROR",
            ErrorMessage = validationError,
            Content = command.Content,
            CorrelationId = command.CorrelationId
        };

        await _eventPublisher.PublishAsync(failureEvent, cancellationToken);
    }

    private async Task PublishUnexpectedErrorEvent(SendSmsCommand command, string errorMessage, CancellationToken cancellationToken)
    {
        var failureEvent = new SmsSubmissionFailedEvent
        {
            EventId = Guid.NewGuid().ToString(),
            CommandId = command.CommandId,
            PhoneNumber = command.PhoneNumber,
            ErrorCode = "UNEXPECTED_ERROR",
            ErrorMessage = errorMessage,
            Content = command.Content,
            CorrelationId = command.CorrelationId
        };

        await _eventPublisher.PublishAsync(failureEvent, cancellationToken);
    }

    private async Task StoreIdempotencyRecord(string idempotencyKey, SmsEventBase eventData, CancellationToken cancellationToken)
    {
        var cachedResult = new CachedEventResult
        {
            EventId = eventData.EventId,
            EventType = eventData.GetType().Name,
        };

        var serializedResult = JsonSerializer.Serialize(cachedResult);
        await _keyValueStore.SetKeyAsync(idempotencyKey, serializedResult,  cancellationToken);
    }

    private static string GetIdempotencyKey(string commandId) => $"{IdempotencyKeyPrefix}{commandId}";

    private class CachedEventResult
    {
        public required string EventId { get; init; }
        public required string EventType { get; init; }
    }
}
